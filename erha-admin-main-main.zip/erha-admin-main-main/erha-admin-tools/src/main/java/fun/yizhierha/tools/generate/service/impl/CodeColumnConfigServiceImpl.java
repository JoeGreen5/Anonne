package fun.yizhierha.tools.generate.service.impl;

import fun.yizhierha.tools.generate.domain.CodeColumnConfig;
import fun.yizhierha.tools.generate.mapper.CodeColumnConfigMapper;
import fun.yizhierha.tools.generate.service.CodeColumnConfigService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
@Service
public class CodeColumnConfigServiceImpl extends ServiceImpl<CodeColumnConfigMapper, CodeColumnConfig> implements CodeColumnConfigService {

}
