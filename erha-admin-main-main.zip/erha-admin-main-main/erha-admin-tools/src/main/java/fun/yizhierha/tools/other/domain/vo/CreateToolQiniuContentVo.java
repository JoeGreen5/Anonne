package fun.yizhierha.tools.other.domain.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


@Data
public class CreateToolQiniuContentVo{

}