package fun.yizhierha.tools.other.service;

import fun.yizhierha.tools.other.domain.vo.SendEmailVo;

public interface ToolEmailService {
    void sendEmail(SendEmailVo sendEmailVo);
}
