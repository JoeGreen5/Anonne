package fun.yizhierha.tools.generate.service;

import com.baomidou.mybatisplus.extension.service.IService;
import fun.yizhierha.tools.generate.domain.CodeColumnConfig;

public interface CodeColumnConfigService extends IService<CodeColumnConfig>{


}
