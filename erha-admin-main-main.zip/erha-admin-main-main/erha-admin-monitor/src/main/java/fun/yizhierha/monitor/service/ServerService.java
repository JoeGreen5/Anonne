package fun.yizhierha.monitor.service;

import java.util.Map;

public interface ServerService {
    Map<String,Object> getServerInfo();
}
