package fun.yizhierha.modules.security.service;

import org.springframework.stereotype.Component;

@Component
public class UserCacheClean {
}
