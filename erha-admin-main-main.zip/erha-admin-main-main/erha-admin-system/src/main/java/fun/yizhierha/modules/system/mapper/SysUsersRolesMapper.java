package fun.yizhierha.modules.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import fun.yizhierha.modules.system.domain.SysUsersRoles;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysUsersRolesMapper extends BaseMapper<SysUsersRoles> {
}