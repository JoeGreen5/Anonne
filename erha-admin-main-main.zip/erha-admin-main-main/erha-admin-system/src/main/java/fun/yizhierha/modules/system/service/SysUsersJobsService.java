package fun.yizhierha.modules.system.service;

import fun.yizhierha.modules.system.domain.SysUsersJobs;
import com.baomidou.mybatisplus.extension.service.IService;
public interface SysUsersJobsService extends IService<SysUsersJobs>{


}
