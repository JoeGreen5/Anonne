package fun.yizhierha.modules.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import fun.yizhierha.modules.system.domain.SysUsersJobs;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysUsersJobsMapper extends BaseMapper<SysUsersJobs> {
}