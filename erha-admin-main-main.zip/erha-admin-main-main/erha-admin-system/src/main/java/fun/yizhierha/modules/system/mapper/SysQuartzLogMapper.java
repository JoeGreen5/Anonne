package fun.yizhierha.modules.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import fun.yizhierha.modules.system.domain.SysQuartzLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysQuartzLogMapper extends BaseMapper<SysQuartzLog> {
}