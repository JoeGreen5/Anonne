package fun.yizhierha.modules.system.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import fun.yizhierha.modules.system.domain.SysRolesMenus;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysRolesMenusMapper extends BaseMapper<SysRolesMenus> {
}