package fun.yizhierha.operation.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import fun.yizhierha.operation.domain.OraDeployServer;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OraDeployServerMapper extends BaseMapper<OraDeployServer> {
}
